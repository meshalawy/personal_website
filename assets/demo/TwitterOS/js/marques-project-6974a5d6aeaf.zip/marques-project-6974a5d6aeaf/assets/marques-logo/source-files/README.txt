The source files for the MARQues logo were sourced from the Open Clip Art Library (http://www.openclipart.org/)

- http://www.openclipart.org/detail/85393/search-for-fingerprints-by-jhnri4
- http://www.openclipart.org/detail/120607/treasure-map-by-tzunghaor
