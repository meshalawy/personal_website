The mind maps in this folder have been created using MindNode (http://www.mindnode.com/)
