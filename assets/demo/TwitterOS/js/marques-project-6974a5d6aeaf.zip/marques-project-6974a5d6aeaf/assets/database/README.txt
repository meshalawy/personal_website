The database-schema.sql file is a dump of the database created using the mysqldump command to 
assist in creating the required database in another server instance.

The mysqlviz script uses the database-schema.sql file to create a dot file for use with Grpahviz in order to create a nice image. More information on mysqlviz is available here: http://code.google.com/p/mysqlviz/.