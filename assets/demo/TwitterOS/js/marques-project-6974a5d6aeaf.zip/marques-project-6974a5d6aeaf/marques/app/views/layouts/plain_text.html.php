<?php
/**
 * MARQUes - Maps Answering Research Questions
 *
 * @copyright     Copyright 2011, Flinders University (http://www.flinders.edu.au)
 * @license       http://opensource.org/licenses/bsd-license.php The BSD License
 *
 * Original Template Design by Jason Cole (http://jasoncole.ca/) and released into the Public Domain
 */		

// output the page content
echo $this->content();
?>
